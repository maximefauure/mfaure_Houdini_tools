import sys
import os
if not r'C:\Users\public\pipeline\pmp' in sys.path:
   sys.path.append(r'C:\Users\public\pipeline\pmp')
# sg connection

from sg.core.ShotgunCore import getScriptUser
from sg.core.ShotgunCore import getSg
script = getScriptUser()
sg = getSg(script)



import sgtk
from hou import * 
from PySide2 import QtCore, QtUiTools,QtWidgets

currentFile = hou.hipFile.name()
nodeType = hou.pwd().type().name() 


currentPath = ""

if nodeType=="rop_alembic" :
    currentPath = hou.pwd().evalParm("filename")

if nodeType=="filecache" :
    currentPath = hou.pwd().evalParm("file")

if nodeType=="rop_geometry" :
    currentPath = hou.pwd().evalParm("sopoutput")


tk = None
basePathCfg = '\\\\montreal\\workflow\\pipeline\\SG_configurations'
projectPath = currentFile.replace("\\","/").split("/01_CONTENT/")[0]
tankName = projectPath.split("/")[-1]
if tankName == 'basic_core':
    tankName = 'pmp_default_core'
if tankName == 'complex_core':
    tankName = 'pmp_complex_core'
if tankName == 'simple_core':
    tankName = 'pmp_simple_core'
cfg_path = basePathCfg + "\\" + tankName
tk = sgtk.sgtk_from_path(cfg_path)
project = tk.entity_from_path(projectPath)
entityPath = currentFile.replace("\\","/").split("/work/")[0]
entity = tk.entity_from_path(entityPath)


publishedFilesSame = sg.find("PublishedFile", [['entity', 'is', entity]], ["path"])



found = False

for f in publishedFilesSame:
    path = f["path"]["local_path"]
    #print(path)
    #print(currentPath)
    if currentPath.replace("\\","/") == path.replace("\\","/"):
        found=True
if found:
    hou.SystemExit("version already found in publish files - please increment version")
    
else :
    hou.ui.displayMessage( "you can render this node - no publish file found")