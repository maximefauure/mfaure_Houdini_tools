from shutil import copyfile
from hou import * 
import os


inPath = hou.pwd().evalParm("file")
newPath =  hou.pwd().evalParm("sopoutputCopy")



copyfile( inPath, newPath)


