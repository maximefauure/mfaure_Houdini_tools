import os
import sys
from hou import * 
import subprocess 
import re

currentFile = hou.hipFile.name()
exportedFile = hou.pwd().evalParm("PathToPublish")
description = hou.pwd().evalParm("description")

# Repo directories
pipeline_root = os.getenv('PIPELINE_ROOT')
pipeline_dev = os.getenv('PIPELINE_DEV')
pipeline_venv = os.getenv('PIPELINE_VENV')
shotgun_desktop = "\\shotgun_desktop_ui"
if not pipeline_root : pipeline_root= "None"

if os.path.exists(pipeline_root):
    # Check if we use the dev repo.
    if os.path.exists(pipeline_root + '\\dev' + shotgun_desktop + '.txt'):
        shotgun_desktop = pipeline_dev + shotgun_desktop
    else:
        shotgun_desktop = pipeline_venv + shotgun_desktop
    sys.path.append(shotgun_desktop + '\\src\\core')

    from ShotgunCore import getSg

elif os.path.exist(r'C:\Users\public\pipeline\pmp'):
    if not r'C:\Users\public\pipeline\pmp' in sys.path:
        sys.path.append(r'C:\Users\public\pipeline\pmp')
    # sg connection
    from sg.core.ShotgunCore import getSg
    
sg=getSg()

import sgtk


def createPublishFile():

    #============== EMPTY FIELD ======================
    if len(exportedFile) ==0 :
        hou.ui.displayMessage("MISSING PATH TO PUBLISH, CANCELING")
        return   

    #============== TEST EXTENSION ======================
    if exportedFile.endswith(".abc") :
        exportType = "abc"
        print ("file is alembic")
    elif exportedFile.endswith(".vdb") :
        exportType = "vdb"
    elif exportedFile.endswith(".fbx") :
        exportType = "fbx"
    else :
        print("FILE NAME MISSING SUPPORTED EXTENSION, CANCELING")
        hou.ui.displayMessage("FILE NAME MISSING SUPPORTED EXTENSION, CANCELING")        
        return

    #============== TEST EXTENSION END =====================

    #============== TEST VERSIONNING SY NTAX ======================
    res = re.findall("\.(v[0-9]*)\.", exportedFile)
    fileNoVersion = os.path.basename(exportedFile).replace(res[0], "").split("..")[0]
    print (fileNoVersion)
    if not res:
        print("FILE NAME NOT CORRECT, IT COULD BE MISSING VERSION (vXXX), CANCELING")
        hou.ui.displayMessage("FILE NAME NOT CORRECT, IT COULD BE MISSING VERSION (vXXX), CANCELING")
        return
    #============== TEST VERSIONNING SYNTAX END ======================

    #============== TEST EXISTING FILE ======================
    if not os.path.exists(exportedFile) : 
        print("THE FILE YOU TRY TO PUBLISH DO NOT EXIST")
        
        hou.ui.displayMessage("THE FILE YOU TRY TO PUBLISH DO NOT EXIST")
        return 
    
    #============== TEST EXISTING FILE END ======================

    versionNum = res[-1]
    #print(versionNum)




    tk = None
    basePathCfg = '\\\\montreal\\workflow\\pipeline\\SG_configurations'
    # A CHANGER : ================================================================================================================
    # ================================================================================================================
    projectPath = currentFile.replace("\\", "/").split("/01_CONTENT/")[0]
    tankName = projectPath.split("/")[-1]
    print(tankName)
    if tankName == 'dev_core':
        tankName = 'pmp_dev_core'
    if tankName == 'basic_core':
        tankName = 'pmp_default_core'
    if tankName == 'complex_core':
        tankName = 'pmp_complex_core'
    if tankName == 'simple_core':
        tankName = 'pmp_simple_core'
    cfg_path = basePathCfg + "\\" + tankName
    tk = sgtk.sgtk_from_path(cfg_path)
    if not tk:
        return
    project = tk.entity_from_path(projectPath)
    entityPath = currentFile.replace("\\", "/").split("/work/")[0]
    entity = tk.entity_from_path(entityPath)
    stepPath = os.path.dirname(os.path.dirname(currentFile)).replace("\\", "/")
    step = tk.entity_from_path(stepPath)
    task = sg.find_one("Task", [["step", "is", step], ["entity", "is", entity]])
    data = {}
    
    extension = os.path.basename(exportedFile).split('.')[-1]
    #============== TEST ALREADY PUBLISHED FILE ======================
    publishedFilesSame = sg.find("PublishedFile", [["entity", "is", entity],['code', 'starts_with', fileNoVersion]],
                                 ["version_number"], [{'field_name': 'version_number', 'direction': 'asc'}])
    for pf in publishedFilesSame:
        
        if int(versionNum.replace("v","")) == pf['version_number']:
            print("VERSION IN INPUT FILE ALREADY EXIST, CANCELING")

            hou.ui.displayMessage("VERSION IN INPUT FILE ALREADY EXIST, CANCELING")
            return
    #============== TEST ALREADY PUBLISHED FILE END ======================


    if exportedFile:
        # A CHANGER : ================================================================================================================

        if exportType=="abc" :
            publishedType = sg.find_one("PublishedFileType", [['code', 'is', 'Alembic Cache']])
            print ("file is alembic")
        elif exportType=="vdb" :
            publishedType = sg.find_one("PublishedFileType", [['code', 'is', 'VDB File']])
        elif exportType=="fbx":
            publishedType = sg.find_one("PublishedFileType", [['code', 'is', 'FBX Cache']])
            
        else :
            return
        # ================================================================================================================


        data["published_file_type"] = publishedType
        path = {"local_path": exportedFile.replace("/", "\\")}
        data["path"] = path
        data['code'] = fileNoVersion+"_cache"
        data['name'] = fileNoVersion+"_cache"
        data['description'] = description
        data["entity"] = entity
        data["project"] = project
        data["task"] = task
        data["version_number"] = int(versionNum.replace("v",""))
        print(data)
        print("--------------------------------------")
        sg.create("PublishedFile", data)
    print(currentFile)
    print(description)
    print(exportedFile)

    hou.ui.displayMessage( exportedFile+" published on shotgun")



createPublishFile()
