from shutil import copyfile
from hou import * 
import os


inPath = hou.pwd().evalParm("sopoutput")
newPath =  hou.pwd().evalParm("sopoutputCopy")



copyfile( inPath, newPath)


