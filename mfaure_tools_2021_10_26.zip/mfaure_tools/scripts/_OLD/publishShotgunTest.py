import os
import sys
from hou import * 




currentFile = hou.hipFile.name()
exportedFile = hou.pwd().evalParm("PathToPublish")
description = hou.pwd().evalParm("description")
#sys.argv= [r"//montreal/projets/2018/KFPbp_PeachTreeBoatRide/01_CONTENT/03_PROD/BR/Shots/BR_Sc3/work/fx/hou/KFPbp_BR_Sc3_fx.devScene.v011.hip", r"//montreal/projets/2018/KFPbp_PeachTreeBoatRide/01_CONTENT/03_PROD/BR/Shots/BR_Sc3/cache/fx/hou/abc/PART_04_f1/PART_04_f1.LVL2.abc","LVL 2 alembic PART_04_f1" ]

import subprocess
subprocess.call(["C:\\Users\\Public\\pipeline\\bins\\apps\\Python38\\python.exe", "\\\\montreal\\workflow\\pipeline\\shared\\maximef\\mfaure_tools\\scripts\\appendShotgun.py", currentFile, exportedFile, description])



print (currentFile)
print (exportedFile)
print (description)
# sg connection
#from sg.core.ShotgunCore import getSg
#sg=getSg()
#import sgtk