import sys
import os

if not r'C:\Users\public\pipeline\pmp' in sys.path:
   sys.path.append(r'C:\Users\public\pipeline\pmp')

# sg connection
from sg.core.ShotgunCore import getSg
sg=getSg()

import sgtk

#sys.argv= ["file",r"//montreal/projets/2018/KFPbp_PeachTreeBoatRide/01_CONTENT/03_PROD/BR/Shots/BR_Sc3/work/fx/hou/KFPbp_BR_Sc3_fx.devScene.v011.hip", r"//montreal/projets/2018/KFPbp_PeachTreeBoatRide/01_CONTENT/03_PROD/BR/Shots/BR_Sc3/cache/fx/hou/abc/PART_04_f1/PART_04_f1.LVL2.abc","LVL 2 alembic PART_04_f1" ]

print(sys.argv)
currentFile = sys.argv[1]
exportedFile = sys.argv[2]
description = sys.argv[3]
if not r'C:\Users\public\pipeline\pmp' in sys.path:
   sys.path.append(r'C:\Users\public\pipeline\pmp')
def createPublishFile():
    tk = None
    basePathCfg = '\\\\montreal\\workflow\\pipeline\\SG_configurations'
    #A CHANGER : ================================================================================================================
    tk = None
    basePathCfg = '\\\\montreal\\workflow\\pipeline\\SG_configurations'
    #A CHANGER : ================================================================================================================
    #================================================================================================================
    projectPath = currentFile.replace("\\","/").split("/01_CONTENT/")[0]
    tankName = projectPath.split("/")[-1]
    if tankName == 'basic_core':
        tankName = 'pmp_default_core'
    if tankName == 'complex_core':
        tankName = 'pmp_complex_core'
    if tankName == 'simple_core':
        tankName = 'pmp_simple_core'
    cfg_path = basePathCfg + "\\" + tankName
    tk = sgtk.sgtk_from_path(cfg_path)
    if not tk:
        return
    project = tk.entity_from_path(projectPath)
    entityPath = currentFile.replace("\\","/").split("/work/")[0]
    entity = tk.entity_from_path(entityPath)
    stepPath = os.path.dirname(os.path.dirname(currentFile)).replace("\\","/")
    step = tk.entity_from_path(stepPath)
    task = sg.find_one("Task",[["step","is",step],["entity","is",entity]])
    dir = os.path.dirname(currentFile.replace('/hou/scenes/', '/fbx/'))
    fileName = tankName + "_" + entity['name'] + "_" + description
    data = {}
    publishedFilesSame = sg.find("PublishedFile", [['code', 'starts_with', fileName + "."]],
                                                ["version_number"], [{'field_name': 'version_number', 'direction': 'asc'}])
    
    if not publishedFilesSame:
        versionNum = 0
    else:
        versionNum = publishedFilesSame[-1]['version_number']
    versionNum = versionNum+1
    fileName = fileName + "." + str(versionNum).zfill(3)
    export_file = os.path.join(dir, fileName)
    #A CHANGER : ================================================================================================================
    # ================================================================================================================
    if exportedFile:
        # A CHANGER : ================================================================================================================
        publishedType = sg.find_one("PublishedFileType", [['code', 'is', 'Alembic Cache']])
        # ================================================================================================================
        data["published_file_type"] = publishedType
        path = {"local_path": exportedFile.replace("/","\\")}
        data["path"] = path
        data['code'] = fileName
        data['name'] = fileName
        data["entity"] = entity
        data["project"] = project
        data["task"] = task
        data["version_number"] = versionNum
        print(data)
        print("--------------------------------------")
        sg.create("PublishedFile", data)
    print (currentFile)
    print (description)
    print (exportedFile)
createPublishFile()
