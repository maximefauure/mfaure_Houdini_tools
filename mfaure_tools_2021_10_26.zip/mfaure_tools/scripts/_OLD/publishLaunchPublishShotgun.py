import os
import sys
from hou import * 
import subprocess 
import re


currentFile = hou.hipFile.name()
exportedFile = hou.pwd().evalParm("PathToPublish")
description = hou.pwd().evalParm("description")

if not r'C:\Users\public\pipeline\pmp' in sys.path:
    sys.path.append(r'C:\Users\public\pipeline\pmp')

# sg connection
from sg.core.ShotgunCore import getSg
sg=getSg()

import sgtk

if not r'C:\Users\public\pipeline\pmp' in sys.path:
    sys.path.append(r'C:\Users\public\pipeline\pmp')


def createPublishFile():
    res = re.findall("\.(v[0-9]*)\.", exportedFile)

    if not res:
        print("MISSING VERSION IN INPUT FILE, CANCELING")
        hou.ui.displayMessage("MISSING VERSIONNING (vXXX) IN INPUT FILE, CANCELING")
        return

    if not os.path.exists(exportedFile) : 

        hou.ui.displayMessage("THE FILE YOU TRY TO PUBLISH DO NOT EXIST")
        return 

    versionNum = res[-1]
    print(versionNum)

    tk = None
    basePathCfg = '\\\\montreal\\workflow\\pipeline\\SG_configurations'
    # A CHANGER : ================================================================================================================
    # ================================================================================================================
    projectPath = currentFile.replace("\\", "/").split("/01_CONTENT/")[0]
    tankName = projectPath.split("/")[-1]
    print(tankName)
    if tankName == 'dev_core':
        tankName = 'pmp_dev_core'
    if tankName == 'basic_core':
        tankName = 'pmp_default_core'
    if tankName == 'complex_core':
        tankName = 'pmp_complex_core'
    if tankName == 'simple_core':
        tankName = 'pmp_simple_core'
    cfg_path = basePathCfg + "\\" + tankName
    tk = sgtk.sgtk_from_path(cfg_path)
    if not tk:
        return
    project = tk.entity_from_path(projectPath)
    entityPath = currentFile.replace("\\", "/").split("/work/")[0]
    entity = tk.entity_from_path(entityPath)
    stepPath = os.path.dirname(os.path.dirname(currentFile)).replace("\\", "/")
    step = tk.entity_from_path(stepPath)
    task = sg.find_one("Task", [["step", "is", step], ["entity", "is", entity]])
    data = {}
    fileNoVersion = os.path.basename(exportedFile).split(versionNum)[0]
    extension = os.path.basename(exportedFile).split('.')[-1]
    publishedFilesSame = sg.find("PublishedFile", [["entity", "is", entity],['code', 'starts_with', fileNoVersion],['code', 'ends_with', extension]],
                                 ["version_number"], [{'field_name': 'version_number', 'direction': 'asc'}])

    for pf in publishedFilesSame:

        if int(versionNum.replace("v","")) == pf['version_number']:
            print("VERSION IN INPUT FILE ALREADY EXIST, CANCELING")
            hou.ui.displayMessage("VERSION IN INPUT FILE ALREADY EXIST, CANCELING")
            return

    if exportedFile:
        # A CHANGER : ================================================================================================================
        publishedType = sg.find_one("PublishedFileType", [['code', 'is', 'Alembic Cache']])
        # ================================================================================================================

        NameFile = os.path.basename(exportedFile).replace(res[0], "").split("..")[0]

        data["published_file_type"] = publishedType
        path = {"local_path": exportedFile.replace("/", "\\")}
        data["path"] = path
        data['code'] = NameFile+"_cache"
        data['name'] = NameFile+"_cache"
        data['description'] = description
        data["entity"] = entity
        data["project"] = project
        data["task"] = task
        data["version_number"] = int(versionNum.replace("v",""))
        print(data)
        print("--------------------------------------")
        sg.create("PublishedFile", data)
    print(currentFile)
    print(description)
    print(exportedFile)


    hou.ui.displayMessage( exportedFile+" published on shotgun")



createPublishFile()
