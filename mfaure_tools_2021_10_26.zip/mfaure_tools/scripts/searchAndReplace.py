import hou
from PySide2 import QtCore, QtGui, QtWidgets

class mk_ParameterFindAndReplace_UI(QtWidgets.QDialog):

    def __init__(self, parent=None):
        QtWidgets.QDialog.__init__(self, parent)
        version = 0.01
        self.grp_input = QtWidgets.QGroupBox()
        self.lbl_find = QtWidgets.QLabel('Find: ')
        self.lbl_find.setContentsMargins(5, 0, 0, 0)
        self.edt_find = QtWidgets.QLineEdit()
        self.edt_find.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.lbl_replace = QtWidgets.QLabel('Replace: ')
        self.lbl_replace.setContentsMargins(5, 0, 0, 0)
        self.edt_replace = QtWidgets.QLineEdit()
        self.edt_replace.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.chk_expandVariables = QtWidgets.QCheckBox('Expand Variables When Replacing')
        self.btn_replace = QtWidgets.QPushButton('Replace', self)
        self.btn_replace.setFixedHeight(30)
        self.btn_close = QtWidgets.QPushButton('Close', self)
        self.btn_close.setFixedHeight(30)
        self.resize(450, 50)
        self.setWindowTitle('Parameter Find & Replace v%s' % version)
        self.lay_main = QtWidgets.QVBoxLayout()
        self.lay_grpInput = QtWidgets.QVBoxLayout()
        self.lay_input = QtWidgets.QGridLayout()
        self.lay_buttons = QtWidgets.QHBoxLayout()
        self.lay_input.addWidget(self.lbl_find, 0, 0)
        self.lay_input.addWidget(self.edt_find, 0, 1)
        self.lay_input.addWidget(self.lbl_replace, 1, 0)
        self.lay_input.addWidget(self.edt_replace, 1, 1)
        self.lay_input.addWidget(self.chk_expandVariables, 2, 1)
        self.lay_grpInput.addLayout(self.lay_input)
        self.lay_buttons.addWidget(self.btn_replace)
        self.lay_buttons.addWidget(self.btn_close)
        self.grp_input.setLayout(self.lay_grpInput)
        self.lay_main.addWidget(self.grp_input)
        self.lay_main.addLayout(self.lay_buttons)
        self.setLayout(self.lay_main)
        self.edt_find.textChanged.connect(self.findChanged)
        self.edt_replace.textChanged.connect(self.replaceChanged)
        self.btn_replace.clicked.connect(self.replace)
        self.btn_close.clicked.connect(self.close)

    def findChanged(self):
        if self.edt_find.text() == '':
            hou.ui.setStatusMessage('Please specify text to find.', severity=hou.severityType.Warning)
        else:
            hou.ui.setStatusMessage('')

    def replaceChanged(self):
        if self.edt_replace.text() == '':
            hou.ui.setStatusMessage('Please specify text to replace with.', severity=hou.severityType.Warning)
        else:
            hou.ui.setStatusMessage('')

    def replace(self):
        str_find = self.edt_find.text()
        if '//' in str_find:
            hou.ui.setStatusMessage('Find and replace cannot find parameters with //.', severity=hou.severityType.Warning)
        str_find = str_find.replace('\\$', '$')
        str_find = str_find.replace('$', '\\$')
        str_replace = self.edt_replace.text()
        if not self.chk_expandVariables.isChecked():
            str_replace = str_replace.replace('\\$', '$')
            str_replace = str_replace.replace('$', '\\$')
        if str_find == '':
            hou.ui.setStatusMessage('Please specify text to find.', severity=hou.severityType.Warning)
        elif str_replace == '':
            hou.ui.setStatusMessage('Please specify text to replace with.', severity=hou.severityType.Warning)
        else:
            with hou.undos.group('Parameter Find And Replace'):
                hou.hscript('opchange "%s" "%s"' % (str_find, str_replace))





existingDialogs = []
for entry in hou.qt.mainWindow().children():
        window = 'mk_ParameterFindAndReplace_UI'
        name = entry.objectName()
        if window == name:
                existingDialogs.append(name)
                dialog = entry
                dialog.activateWindow()
                dialog.setWindowState(QtCore.Qt.WindowActive)

if len(existingDialogs) == 0:
        dialog = mk_ParameterFindAndReplace_UI()
        dialog.setParent(hou.qt.mainWindow(), QtCore.Qt.Window)
        dialog.edt_find.setFocus()
        dialog.show()
        dialog.setObjectName('mk_ParameterFindAndReplace_UI')
        dialog.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        hou.session.dummy = dialog
